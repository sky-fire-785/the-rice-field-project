// This loop runs once for every monitor connected to the PC
for (var i = 0; i < screenIds.length; i++) {
    var screen = screenIds[i];

    // 1. Create the standard bottom panel for this specific screen
    var panel = new Panel("org.kde.panel");
    panel.location = "bottom";
    panel.height = 46; // Standard default Plasma height
    panel.screen = screen;

    // 2. Add the Kickoff Application Launcher (The KDE Start Menu)
    panel.addWidget("org.kde.plasma.kickoff");

    // 3. Add the Task Manager (Icons-only version, which is the modern default)
    var tasks = panel.addWidget("org.kde.plasma.icontasks");

    // 4. PIN YOUR SPECIFIC APPS!
    // Notice how we use the exact .desktop file names from your installer script
    tasks.currentConfigGroup = ["General"];
    tasks.writeConfig("launchers", "applications:org.kde.dolphin.desktop,applications:vivaldi-stable.desktop,applications:kitty.desktop,applications:visual-studio-code.desktop");

    // 5. Add the invisible separator that pushes the system tray to the far right
    panel.addWidget("org.kde.plasma.marginsseparator");

    // 6. Add the System Tray (Wi-Fi, Bluetooth, Audio, etc.)
    panel.addWidget("org.kde.plasma.systemtray");

    // 7. Add the Digital Clock
    panel.addWidget("org.kde.plasma.digitalclock");

    // 8. Add the "Show Desktop" button to the extreme bottom right corner
    panel.addWidget("org.kde.plasma.showdesktop");
}
